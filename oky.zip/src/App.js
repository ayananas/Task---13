import "./App.css";
import LandingPage from "./components/screens/LandingPage";

function App() {
  return <LandingPage />;
}

export default App;
